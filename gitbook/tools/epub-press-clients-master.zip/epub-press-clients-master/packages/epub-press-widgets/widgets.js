import ListWidget from './lib/list.js';
import ItemWidget from './lib/item.js';

export default { ListWidget, ItemWidget };
