# Changelog

### 0.12.0

-   Removes unused permissions.

### 0.11.0

-   Fix for invalid filenames causing the extension to break.
-   Timeout for all downloads of 30 seconds.

### 0.10.2

-   Update file download npm module to fix failed file downloads.

### 0.10.0

-   Adds a progress bar.

### 0.9.0

-   Switches to using `epub-press-js`
-   Javascript is now bundled using webpack.
-   Files are downloaded with the given title.
